
import "dotenv/config";
console.log(
  "JWT SECRET LOADED:",
  Boolean(process.env.SECRET_KEY)
);
console.log("ENV FILE CHECK:", process.env.SECRET_KEY ? "LOADED" : "MISSING");
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";

import connectDB from "./db.js";
import userRouter from "./Routers/User.js";

const app = express();
app.use((req, res, next) => {
  console.log("REQUEST:", req.method, req.url);
  next();
});
// Middleware FIRST
app.use(cors({
  origin: true,
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Routes AFTER middleware
app.use("/api/v1", userRouter);

// Health check
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Restaurant API is working",
  });
});

// Start server after database connection
const startServer = async () => {
  try {
    await connectDB();

    const PORT = process.env.PORT || 5000;

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on port ${PORT}`);
    });

  } catch (error) {
    console.error("Server startup failed:", error);
    process.exit(1);
  }
};

startServer();

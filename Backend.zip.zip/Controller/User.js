
import User from "../Schema/User.js";
import bcrypt from "bcryptjs";
import sendToken from "../utils/Token.js";
import cloudinary from "../utils/Cloudinary.js";

// SIGN UP
export const signUp = async (req, res) => {
    try {
        let { name, email, password, role } = req.body;

        if (
            typeof name !== "string" ||
            typeof email !== "string" ||
            typeof password !== "string" ||
            typeof role !== "string" ||
            !name.trim() ||
            !email.trim() ||
            !password ||
            !role.trim()
        ) {
            return res.status(400).json({
                success: false,
                message: "Please fill all required fields",
            });
        }

        name = name.trim();
        email = email.trim().toLowerCase();
        role = role.trim();

        console.log("Signup request received:", email);

        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: "User already exists. Please login.",
            });
        }

        // Let the User schema handle password hashing if it
        // already has a pre-save hashing hook.
        const user = await User.create({
            name,
            email,
            password,
            role,
        });

        console.log("Signup successful:", user.email);

        return sendToken(user, 201, res);
    } catch (error) {
        console.error("Signup error:", error);

        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                message: "This email is already registered.",
            });
        }

        if (error.name === "ValidationError") {
            return res.status(400).json({
                success: false,
                message: error.message,
            });
        }

        return res.status(500).json({
            success: false,
            message: "Signup failed. Check the backend terminal.",
        });
    }
};

// SIGN IN
export const signIn = async (req, res) => {
    try {
        let { email, password } = req.body;

        if (
            typeof email !== "string" ||
            typeof password !== "string" ||
            !email.trim() ||
            !password
        ) {
            return res.status(400).json({
                success: false,
                message: "Please provide email and password",
            });
        }

        email = email.trim().toLowerCase();

        const user = await User.findOne({ email }).select("+password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User does not exist. Please signup.",
            });
        }

        const passwordMatches = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatches) {
            return res.status(401).json({
                success: false,
                message: "Email or password is incorrect",
            });
        }

        return sendToken(user, 200, res);
    } catch (error) {
        console.error("Signin error:", error);
        return res.status(500).json({
            success: false,
            message: "Signin failed",
        });
    }
};

// LOG OUT
export const logOut = async (req, res) => {
    try {
        return res
            .status(200)
            .cookie("token", null, {
                expires: new Date(0),
                httpOnly: true,
            })
            .json({
                success: true,
                message: "Logged out successfully",
            });
    } catch (error) {
        console.error("Logout error:", error);
        return res.status(500).json({
            success: false,
            message: "Logout failed",
        });
    }
};

// UPDATE PASSWORD
export const updatePassword = async (req, res) => {
    try {
        const { oldPassword, newPassword } = req.body;

        if (!oldPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: "Provide both old and new passwords",
            });
        }

        const user = await User.findById(req.user._id).select("+password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        const matches = await bcrypt.compare(oldPassword, user.password);

        if (!matches) {
            return res.status(400).json({
                success: false,
                message: "Old password is incorrect",
            });
        }

        // The User schema should hash the password on save.
        user.password = newPassword;
        await user.save();

        return res.status(200).json({
            success: true,
            message: "Password updated successfully",
        });
    } catch (error) {
        console.error("Update password error:", error);
        return res.status(500).json({
            success: false,
            message: "Password update failed",
        });
    }
};

// GET ALL USERS
export const getAllUsers = async (req, res) => {
    try {
        const users = await User.find().select("-password");

        return res.status(200).json({
            success: true,
            count: users.length,
            users,
        });
    } catch (error) {
        console.error("Get all users error:", error);
        return res.status(500).json({
            success: false,
            message: "Could not fetch users",
        });
    }
};

// GET USER BY ID
export const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select("-password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        return res.status(200).json({
            success: true,
            user,
        });
    } catch (error) {
        console.error("Get user error:", error);
        return res.status(500).json({
            success: false,
            message: "Could not fetch user",
        });
    }
};

// UPDATE USER
export const updateUser = async (req, res) => {
    try {
        const { name, email, role } = req.body;
        const updates = {};

        if (name !== undefined) updates.name = name;
        if (email !== undefined) updates.email = email.trim().toLowerCase();
        if (role !== undefined) updates.role = role;

        const user = await User.findByIdAndUpdate(
            req.params.id,
            updates,
            { new: true, runValidators: true }
        ).select("-password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        return res.status(200).json({
            success: true,
            message: "User updated successfully",
            user,
        });
    } catch (error) {
        console.error("Update user error:", error);
        return res.status(500).json({
            success: false,
            message: "Could not update user",
        });
    }
};

// DELETE USER
export const deleteUser = async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        return res
            .status(200)
            .cookie("token", null, {
                expires: new Date(0),
                httpOnly: true,
            })
            .json({
                success: true,
                message: "User deleted successfully",
            });
    } catch (error) {
        console.error("Delete user error:", error);
        return res.status(500).json({
            success: false,
            message: "Could not delete user",
        });
    }
};

// UPDATE PROFILE IMAGE
export const updateProfileImage = async (req, res) => {
    try {
        const { profileImage } = req.body;

        if (!profileImage) {
            return res.status(400).json({
                success: false,
                message: "Please provide a profile image",
            });
        }

        const user = await User.findById(req.user._id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        if (user.profileImage?.public_id) {
            await cloudinary.uploader.destroy(
                user.profileImage.public_id
            );
        }

        user.profileImage = profileImage;
        await user.save();

        return res.status(200).json({
            success: true,
            message: "Profile image updated successfully",
            user,
        });
    } catch (error) {
        console.error("Update profile image error:", error);
        return res.status(500).json({
            success: false,
            message: "Could not update profile image",
        });
    }
};
